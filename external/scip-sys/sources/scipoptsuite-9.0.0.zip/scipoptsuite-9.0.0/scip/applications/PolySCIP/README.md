PolySCIP
=====================================================================

PolySCIP is a solver for multi-criteria
integer programming and multi-criteria linear programming
problems. The name PolySCIP is composed of Poly (from the Greek πολύς
meaning "many") and SCIP.

For further information please visit https://polyscip.zib.de/.

Building and installing the Sudoku example
================================================

Please refer to the INSTALL_APPLICATIONS_EXAMPLES.md file in the scip directory.

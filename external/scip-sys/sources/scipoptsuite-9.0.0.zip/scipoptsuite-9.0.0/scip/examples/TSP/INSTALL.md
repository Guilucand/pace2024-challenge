Building and installing the TSP example
================================================

Please refer to the INSTALL_APPLICATIONS_EXAMPLES.md file in the scip directory.

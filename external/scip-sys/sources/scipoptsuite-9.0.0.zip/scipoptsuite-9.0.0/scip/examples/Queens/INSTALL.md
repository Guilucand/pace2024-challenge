Building and installing the Queens example
================================================

Please refer to the INSTALL_APPLICATIONS_EXAMPLES.md file in the scip directory.

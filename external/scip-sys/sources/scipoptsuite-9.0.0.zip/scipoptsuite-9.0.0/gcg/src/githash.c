#define GCG_GITHASH "f1060d8a"
